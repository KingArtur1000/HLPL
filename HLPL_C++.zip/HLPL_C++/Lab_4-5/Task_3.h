#pragma once

double calculateCompoundInterest(double principal, double rate, int years) {
    return principal * std::pow(1 + rate / 100, years);
}
